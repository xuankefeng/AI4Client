# Student Resources for this Course

More COMING SOON!

##  Student Quick Start

To begin, satisfy some pre-reqs and go through an example using the .NET Bot Builder SDK.  This introductory lab is located in this repository [here](Student-Resources/Labs/Lab_Getting_Started.md).

For a Node.js getting started lab, try out [this](https://github.com/michhar/bot-education-ocrbot/blob/master/LabStart.md) one in which you create an simple, yet intelligent OCR bot.

You'll need an IDE or good code editor (Visual Studio 2015 or Visual Studio Code are recommended - both are free) and the Bot Emulator, along with other development tools and subscriptions listed in the labs.

Hope this inspires you to build more amazing bots!
