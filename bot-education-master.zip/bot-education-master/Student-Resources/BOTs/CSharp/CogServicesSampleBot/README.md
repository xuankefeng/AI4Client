## CogServicesSampleBot

This is a bot based on the Microsoft Bot Framework template which contains Microsoft Cognitive Services API call code snippets.  It is meant to illustrate the process of Cognitive Service API calls from within a bot.  Snippets include or will include:

1.  Speech API (Speaker Recognition)
*  Knowledge API (ELIS)
*  Language API (Text Analytics)
*  Bing Search API (News)
*  Vision API (Emotion API with Video)
