﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CogServicesSampleBot.Utilities
{
    public class Keys
    {

        // Keys are found on Cognitive Services subscriptions page (click on My Account)

        // Speaker Recognition API subscription key
        public const string SpeakerRecogSubscriptionKey = "YOUR COGNITIVE SERVICES API KEY FOR SPEAKER RECOG";

        // Place your other keys here as well to be consumed by MessagesController...
    }
}