/*-----------------------------------------------------------------------------
This Bot demonstrates basic bot setup, processing user intents and triggered
actions.

It's part of the bot-education labs.

Try this out with a test dialog ("hi", "echo", "add" and "bye").
Does it work as expected?  Any changes needed?

-----------------------------------------------------------------------------*/

// Required packages
var builder = require('botbuilder');
var restify = require('restify');

//============================================================
// Setting up server, connector
//============================================================

// Connector options
var botConnectorOptions = {
    appId: process.env.MICROSOFT_APP_ID || "",
    appPassword: process.env.MICROSOFT_APP_PASSWORD || ""
};

// Handle Bot Framework messages with a restify server
var server = restify.createServer();
server.listen(process.env.port || process.env.PORT || 3978, function () {
   //When testing on a local machine, 3978 indicates the port to test on
   console.log('%s listening to %s', server.name, server.url); 
});

// Instatiate the chat connector to route messages and create chat bot
var connector = new builder.ChatConnector(botConnectorOptions);
server.post('/api/messages', connector.listen());

//============================================================
// Defining how bot carries on the conversation with the user
//============================================================

// Begin intent logic setup.  An intent is an action a user wants
// to perform.  They, in general, are grouped as expressions that mean
// the same thing, but may be constructed differently.  We can have as
// many as we like here.
var intents = new builder.IntentDialog();

// Create bot and add intent logic (defined later on)
var bot = new builder.UniversalBot(connector);

bot.dialog('/', intents);

//============================================================
// Set up the intents
//============================================================

// Just-say-hi intent logic
intents.matches(/^hi|^Hi|^hello|^Hello/i, function(session) {
    session.send("Hi there!");
});

// Repeat-back utterence intent logic
intents.matches(/echo|Echo/i, [
    // We have a two-part waterfall here
    function (session) {
        // Let's use a built-in prompt to easily collect input
        builder.Prompts.text(session, "What would you like me to say?");
    },
    function (session, results) {
        session.send("Ok... %s", results.response);
    }
]);

// A calculator-type intent logic
intents.matches(/add|Add/i, [
    // We have a three-part waterfall here
    function (session) {
        // Let's use a built-in prompt to easily collect input
        builder.Prompts.number(session, "first number: ");
    },
    function (session, results) {
        // dialogData, as you'll see, is a nice temp place to store things
        session.dialogData.firstnum = results.response;
        builder.Prompts.number(session, "second number: ");
    },
    function (session, results) {
        total = results.response + session.dialogData.firstnum;
        session.send("Your grand total is = %d", total);
    }
]);

// Default intent when what user typed is not matched
intents.onDefault(builder.DialogAction.send("One more time, please?"));

//============================================================
// Set up some trigger actions
//============================================================

// Example of a triggered action - when user types something matched by
// the trigger, this dialog begins, clearing the stack and interrupting
// the current dialog (so be cognizant of this).
// What if we had put 'send' instead of 'endDialog' here - try this.
bot.dialog('/bye', function (session) {
    // end dialog with a cleared stack.  we may want to add an 'onInterrupted'
    // handler to this dialog to keep the state of the current
    // conversation by doing something with the dialog stack
    session.endDialog("Ok... See you later.");
}).triggerAction({matches: /^bye|Bye/i});

//============================================================
// Add-ons
//============================================================

// intents.onBegin(function (session, args, next) {
//     session.dialogData.name = args.name;
//     session.send("Hi %s...", args.name);
//     next();
// });


// Serve a static web page - for testing deployment (note: this is optional)
server.get(/.*/, restify.serveStatic({
	'directory': '.',
	'default': 'index.html'
}));



// More samples here:  https://github.com/Microsoft/BotBuilder-Samples
// And of course here:  https://github.com/Microsoft/BotBuilder/tree/master/Node/examples
